<?php

namespace Spatie\Backtrace\Arguments\ReducedArgument;

interface ReducedArgumentContract
{

}
